package com.example.youtubeshorts;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.lang.String;

public class MainActivity extends AppCompatActivity {

    private EditText searchEditText;
    private Button startButton;
    private WindowManager windowManager;
    private View floatingView;
    private TextView debugTextView; // Added for debugging output

    private static final int OVERLAY_PERMISSION_REQUEST_CODE = 1001;
    private final Handler handler = new Handler();
    private static String Main_URL = "https://m.youtube.com/shorts/4EIWEl9FVTA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEditText = findViewById(R.id.searchEditText);
        startButton   = findViewById(R.id.startButton);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        debugTextView = findViewById(R.id.debugText); // Initialize debugTextView
        debugTextView.setMovementMethod(new ScrollingMovementMethod()); // Enable scrolling

        startButton.setOnClickListener(v -> startFloatingPlayer());
    }

    // Method to append messages to the debug TextView
    private void logToDebugView(String message) {
        runOnUiThread(() -> {
            debugTextView.append(message + "\n");
            // Scroll to the bottom
            final int scrollAmount = debugTextView.getLayout().getLineTop(debugTextView.getLineCount()) - debugTextView.getHeight();
            if (scrollAmount > 0)
                debugTextView.scrollTo(0, scrollAmount);
            else
                debugTextView.scrollTo(0, 0);
        });
    }

    /* ---------- ENTRY POINT ---------- */
    private void startFloatingPlayer() {
        String query = searchEditText.getText().toString().trim();
        hideKeyboard();
        logToDebugView("Starting player with query: " + (query.isEmpty() ? "default URL" : query));

        if (!checkOverlayPermission(Main_URL)) {
            return; // TUNGGU IZIN
        }
        if (query.isEmpty()) {
           // Toast.makeText(this, "Ketik kata kunci dulu", Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "YT Short Dimulai!", Toast.LENGTH_SHORT).show();
            createFloatingWindow(Main_URL);
            return;
        } else {
            Toast.makeText(this, "YT Short Dimulai!", Toast.LENGTH_SHORT).show();
            searchShortsPureYouTube(query);
        }
    }

    /* ---------- SEARCH 1 SHORTS ---------- */
    private void searchShortsPureYouTube(String query) {
        new Thread(() -> {
            try {
                String encoded   = URLEncoder.encode(query, "UTF-8");
                String searchUrl = "https://www.youtube.com/results?search_query=" + encoded + "&sp=EgQQARgB";
                logToDebugView("Searching YouTube with URL: " + searchUrl);

                OkHttpClient client = new OkHttpClient.Builder()
                        .connectTimeout(10, TimeUnit.SECONDS)
                        .readTimeout(15, TimeUnit.SECONDS)
                        .build();

                Request request = new Request.Builder()
                        .url(searchUrl)
                        .addHeader("User-Agent",
                                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                                "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36")
                        .addHeader("Accept-Language", "en-US,en;q=0.9")
                        .addHeader("Cookie", "CONSENT=YES+cb.20221218-17-p0.cs+FX+917")
                        .build();

                Response response = client.newCall(request).execute();
                if (!response.isSuccessful() || response.body() == null) {
                    logToDebugView("Failed to get response from YouTube: " + response.code());
                    runOnUiThread(() -> Toast.makeText(this, "Gagal memuat hasil pencarian.", Toast.LENGTH_SHORT).show());
                    return;
                }

                String html       = response.body().string();
                // logToDebugView("Received HTML (first 500 chars): " + html.substring(0, Math.min(html.length(), 500)));

                String shortsPath = extractFirstShortsPathFromJson(html);
                if (shortsPath == null) {
                    logToDebugView("JSON extraction failed, trying regex fallback.");
                    shortsPath = extractFirstShortsPath(html);
                }

                if (shortsPath == null) {
                    logToDebugView("No shorts found for query: " + query);
                    runOnUiThread(() -> Toast.makeText(this, "Tidak ada Shorts yang ditemukan untuk '" + query + "'.", Toast.LENGTH_LONG).show());
                    return;
                }

                String correctUrl = "https://www.youtube.com" + shortsPath;
                logToDebugView("Found Shorts URL: " + correctUrl);
                
                runOnUiThread(() -> {
                   // Toast toast = Toast.makeText(this, correctUrl, Toast.LENGTH_SHORT);
                   // toast.show();
                    handler.postDelayed(() -> createFloatingWindow(correctUrl), 2000);
                });

            } catch (Exception e) {
                logToDebugView("Error during shorts search: " + e.getMessage());
                runOnUiThread(() -> Toast.makeText(this, "Error saat mencari Shorts.", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    /* ---------- EXTRACT JSON ---------- */
    private String extractFirstShortsPathFromJson(String html) {
        try {
            String startMarker = "var ytInitialData = ";
            int startIdx = html.indexOf(startMarker);
            if (startIdx == -1) {
                logToDebugView("ytInitialData marker not found.");
                return null;
            }
            startIdx += startMarker.length();
            int endIdx = html.indexOf(";</script>", startIdx);
            if (endIdx == -1) {
                logToDebugView("Closing script tag not found after ytInitialData.");
                return null;
            }

            JSONObject root = new JSONObject(html.substring(startIdx, endIdx));
            logToDebugView("Parsed ytInitialData JSON successfully.");

            JSONArray contents = root.getJSONObject("contents")
                    .getJSONObject("twoColumnSearchResultsRenderer")
                    .getJSONObject("primaryContents")
                    .getJSONObject("sectionListRenderer")
                    .getJSONArray("contents");

            for (int i = 0; i < contents.length(); i++) {
                JSONObject section = contents.getJSONObject(i);
                if (!section.has("itemSectionRenderer")) continue;
                JSONArray items = section.getJSONObject("itemSectionRenderer")
                        .getJSONArray("contents");
                for (int j = 0; j < items.length(); j++) {
                    JSONObject item = items.getJSONObject(j);
                    if (!item.has("videoRenderer")) continue;

                    JSONObject videoRenderer = item.getJSONObject("videoRenderer");
                    String videoId = videoRenderer.getString("videoId");
                    logToDebugView("Found video ID: " + videoId);

                    boolean isShorts = false;
                    if (videoRenderer.has("badges")) {
                        JSONArray badges = videoRenderer.getJSONArray("badges");
                        for (int k = 0; k < badges.length(); k++) {
                            JSONObject b = badges.getJSONObject(k)
                                    .getJSONObject("metadataBadgeRenderer");
                            if (b.has("label") && b.getString("label").toLowerCase().contains("shorts")) {
                                isShorts = true;
                                logToDebugView("Video " + videoId + " has 'Shorts' badge.");
                                break;
                            }
                        }
                    }
                    if (!isShorts && videoRenderer.has("lengthText")) {
                        String dur = videoRenderer.getJSONObject("lengthText")
                                .getString("simpleText");
                        isShorts = durationUnder60(dur);
                        logToDebugView("Video " + videoId + " duration: " + dur + ", isShorts based on duration: " + isShorts);
                    }
                    if (isShorts && videoId.matches("[a-zA-Z0-9_-]{11}")) {
                        logToDebugView("Returning Shorts: /shorts/" + videoId);
                        return "/shorts/" + videoId;
                    }
                }
            }
        } catch (Exception e) {
            logToDebugView("Error during JSON extraction: " + e.getMessage());
        }
        return null;
    }

    /* ---------- HTML REGEX FALLBACK ---------- */
    private String extractFirstShortsPath(String html) {
        Pattern p = Pattern.compile("href=\"/shorts/([a-zA-Z0-9_-]{11})\"");
        Matcher m = p.matcher(html);
        if (m.find()) {
            logToDebugView("Found Shorts via regex: /shorts/" + m.group(1));
            return "/shorts/" + m.group(1);
        }
        logToDebugView("No Shorts found via regex.");
        return null;
    }

    private boolean durationUnder60(String dur) {
        try {
            String[] p = dur.split(":");
            int sec = Integer.parseInt(p[p.length - 1]);
            if (p.length > 1) sec += Integer.parseInt(p[0]) * 60;
            return sec <= 60;
        } catch (Exception e) {
            logToDebugView("Error parsing duration '" + dur + "': " + e.getMessage());
            return false;
        }
    }

    /* ---------- FLOATING WINDOW ---------- */
    @SuppressLint("InflateParams")
    private void createFloatingWindow(String url) {
        try {
            if (floatingView != null) {
                windowManager.removeView(floatingView); floatingView = null;
                logToDebugView("Removed existing floating window.");
            }
            floatingView = LayoutInflater.from(this).inflate(R.layout.floating_window, null);

            WebView webView = floatingView.findViewById(R.id.floatingWebView);
            setupWebView(webView, url);

            Button closeButton = floatingView.findViewById(R.id.closeButton);
            closeButton.setOnClickListener(v -> removeFloatingWindow());

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;

            windowManager.addView(floatingView, params);
            setupDragListener(params);
            logToDebugView("Floating window created for URL: " + url);
        } catch (Exception e) {
            logToDebugView("Error creating floating window: " + e.getMessage());
        }
    }

    private void setupDragListener(WindowManager.LayoutParams params) {
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY; private float initialTouchX, initialTouchY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x; initialY = params.y;
                        initialTouchX = event.getRawX(); initialTouchY = event.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params); return true;
                    case MotionEvent.ACTION_UP:
                        int w = v.getWidth(), sw = getResources().getDisplayMetrics().widthPixels;
                        params.x = (params.x + w / 2) < sw / 2 ? 0 : sw - w;
                        windowManager.updateViewLayout(floatingView, params); return true;
                } return false;
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView(WebView webView, String url) {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String u) {
                v.postDelayed(() -> injectCleanScript(v), 2000);
                logToDebugView("WebView finished loading page: " + u);
            }
        });
        webView.loadUrl(url);
    }

    private void injectCleanScript(WebView webView) {
        String js = "javascript:(function(){" +
                "try{" +
                "document.querySelectorAll('ytm-mobile-topbar-renderer, ytm-reel-player-overlay-renderer, .reel-player-overlay-actions, ytm-bottom-sheet-renderer, ytm-crawler-description, .ytm-app-promo-renderer').forEach(e=>e.remove?e.remove():e.style.display='none');" +
                "document.body.style='margin:0;padding:0;overflow:hidden;background:#000!important';" +
                "document.documentElement.style.overflow='hidden';" +
                "let c=document.querySelector('#player-shorts-container')||document.querySelector('shorts-page')||document.querySelector('ytm-reel-player');" +
                "if(c)c.style='position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;z-index:999999!important;background:#000!important;';" +
                "document.querySelectorAll('video').forEach(v=>v.style='width:100%!important;height:100%!important;object-fit:contain!important;background:#000!important;');" +
                "let n=document.createElement('div');n.innerHTML='YT Baby';n.style='position:fixed;top:15px;right:15px;background:rgba(0,0,0,0.7);color:#fff;padding:8px 16px;border-radius:8px;z-index:999999;font-size:13px;pointer-events:none;';" +
                "document.body.appendChild(n);setTimeout(()=>{n.style.opacity=0;n.style.transition='opacity 1s';setTimeout(()=>n.remove(),1000);},3000);" +
                "}catch(e){console.error('JS injection error:', e);}" +
                "})();";
        webView.evaluateJavascript(js, null);
        logToDebugView("Injected cleaning script.");
    }

    private void removeFloatingWindow() {
        if (floatingView != null && windowManager != null) {
            try { windowManager.removeView(floatingView); } catch (Exception ignored) {}
            floatingView = null;
            logToDebugView("Floating window removed.");
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (getCurrentFocus() != null)
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (Exception ignored) {}
    }
    
    private boolean checkOverlayPermission(String url) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                // simpan URL agar setelah izin diberikan, langsung jalan
                getIntent().putExtra("PENDING_URL", url);
                startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST_CODE);
                logToDebugView("Requesting overlay permission.");
                return false;
            }
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                logToDebugView("Overlay permission granted.");
                String url = getIntent().getStringExtra("PENDING_URL");
                if (url != null) {
                    createFloatingWindow(url);
                    getIntent().removeExtra("PENDING_URL"); // Clear the extra
                }
            } else {
                Toast.makeText(this, "Izin overlay diperlukan!", Toast.LENGTH_LONG).show();
                logToDebugView("Overlay permission denied.");
            }
        }
    }
}